# Configuración Android - Permisos

Para que la app Flutter pueda hacer llamadas HTTP/HTTPS a la API expuesta por ngrok, el archivo `android/app/src/main/AndroidManifest.xml` debe incluir el permiso de INTERNET.

Flutter ya lo agrega por defecto al crear el proyecto, pero **verifica** que esté presente justo antes de la etiqueta `<application>`:

```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <!-- Permiso para que la app pueda hacer requests HTTP/HTTPS -->
    <uses-permission android:name="android.permission.INTERNET"/>

    <application
        android:label="GestorComm"
        ...
```

**Si vas a probar también con HTTP plano (no recomendado pero útil para localhost):**

Agrega esto dentro de `<application>` para permitir tráfico HTTP no encriptado:

```xml
<application
    android:usesCleartextTraffic="true"
    ...
```

Cuando uses ngrok, las URLs son HTTPS, así que `usesCleartextTraffic` no es necesario.

# Cambios sobre el bundleId / appLabel

En el mismo archivo puedes cambiar el nombre que se muestra debajo del ícono:

```xml
<application
    android:label="GestorComm"
    android:name="${applicationName}"
    android:icon="@mipmap/ic_launcher">
```

Y en `android/app/build.gradle` el applicationId:

```gradle
defaultConfig {
    applicationId "cl.jmolina.gestorcomm"
    ...
}
```
